//
//  Red_black_tree.c
//
//  Created by Federico D'Armini on 25/11/2019.
//

#include "tmp.h"
#include <string.h>
#include <ctype.h>

mynode* red_node_create(mynode*node, int key, int val);

mynode* black_node_create(mynode*node, int key, int val);


void tree_print(mynode*node);


void insert ( mynode*node,mynode*root,int val,int key);

void node_free (mynode* node);

void tree_free (mynode* root);

void welcome();

int isInt (char* string);

int getInput(char* string, size_t string_max); // add parameter to get buffer size



int main (){
    int key=1;
    int height=1;
    char input[12];
    
    welcome();

    mynode*root=NULL;
    getInput(input,12);
    root=black_node_create(NULL,0,0);
    root->parent=NULL;
    root->right=black_node_create(root,key++,atoi(input));
    root->right->parent=root;
    printf("Nodo creato!\n");
    tree_print(root->right);
    printf("Inserisci un numero : \n");
    while (memcmp("\n",input,1)!=0 )
    {
        getInput(input,12);
        insert(root->right,root->right,atoi(input),key++);
        printf("Nodo creato!\n");
        tree_print(root->right);
        printf("Vuoi continuare? Si -> Inserisci un numero, ENTER -> termina\n");
    }
    return 0;
}