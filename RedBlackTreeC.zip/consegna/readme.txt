Salve professore, di seguito descrivo come usare il programma velocemente e un sintetico
recap sulla struttura che ho dato al progetto.

Premetto che dalla nostra ultima chiamata ho fatto dei cambiamenti, di seguito
motiverò anche le mie scelte.

Insieme a questo file trova :

- Red_black_tree.c (main)
- tmp.h (file con tutte le funzioni)

Per compilare digitare sul terminale (anche copia incolla):

gcc Red_black_tree.c -o albero_rosso_nero

Eseguire : ./albero_rosso_nero

How to use : 

Inserire numeri interi decimali, uno alla volta.
Se viene inserito qualcosa diverso (per esempio una stringa) questa viene respinta 
ed è richiesto un nuovo input.

Premere "invio" senza aver inserito un numero prima comporta la conclusione del programma.

N.B. : Viene fatta una stampa dell'albero subito dopo l'inserimento di un nodo e ogni volta che viene
chiamata la funzione "fix".

La "fix" controlla se il nodo inserito commette una violazione e, in caso ne venisse riscontrata
qualcuna, invoca uno dei 3 case possibili e lo stampa su schermo riportando anche il nodo coinvolto (case1, case2 o case3). 
I case sono gli stessi presenti sulle slides del corso sugli alberi rosso-neri.
Nonostante siano solo 3, i casi speculari vengono gestiti dalla fix quindi in realtà questi 
sono 6 (contando come 6o case la fix chiamata sulla radice o sul primo figlio sx o dx di questa).

Durante la stampa, il nodo appena inserito potrebbe comparire in luoghi inaspettati. Questo
perchè la funzione di stampa,per garantire una maggiore leggibilità dell'albero,
necessita di un minimo di nodi inseriti sia a destra che sinistra della radice
quindi è sufficiente inserire 1/2 di nodi nel ramo con meno elementi per avere una stampa simmetrica.
Questo è più evidente quando la stampa non è simmetrica.

Comunque il nodo viene tracciato prima dell'inserimento ed il suo cammino viene esplicitamente
riportato su schermo, quindi anche se la stampa può risultare fuorviante, viene rappresentato
sia il padre del nuovo nodo che il lato in cui esso viene inserito (sinistra o destra del padre).

Inoltre la fix, per ogni violazione riscontrata, ristampa l'albero quindi la situazione complessiva del
programma è chiara in ogni momento.

Andare oltre l'8o livello dell'albero comporta la terminazione del programma perchè la funzione
di stampa cerca di favorire la leggibilità di ogni riga, ad un certo momento insostenibile data la limmitatezza
dei caratteri del terminale .

Principali cambiamenti :

- Adesso il programma non necessita più di un array che salva e ordina i primi 3 elementi inseriti
quindi le rispettive funzioni non sono riportate.

Informazioni primarie :

Ogni nodo ha 3 riferimenti : due ai figli (dx e sx) e uno al padre.

Tutto l'albero viene costruito sul figlio destro di root quindi tenga presente 
che tutti i riferimenti a "root" presenti nel file ".h" sono diretti, in realtà,
a root->right del file ".c". Questo perchè durante la rotazione di un nodo "x",
destra o sinistra che sia, devo poter sempre associare il nuovo nodo che ha sostituito "x" al padre di "x".
Questo accorgimento garantisce sempre il corretto funzionamento delle rotazioni.

L'intero processo è così strutturato :

1 - Viene inserito un valore sul terminale
2 - Questo valore viene validato da getInput e salvato
3 - Si procede poi all'inserimento del nuovo nodo nell'albero
4 - Una volta inserito viene chiamata la fix
5 - Stampa dell'albero 
6 - Si attende un nuovo valore da inserire 

Funzioni principali (tutte definite in tmp.h) :

getInput, riga 479 : 

Prende un valore in input tramite la "fgets", verifica che questo valore sia un intero tramite la
"isInt" (riga 468).

insert(421) : Prende l'intero ricevuto in input e lo inserisce nell'albero.

fix (367) : Controlla se il nodo da controllare viola uno dei 3 case di base.

case 1, case 2, case 3 (da 299 a 330) : Procedono come da slides.

rotazioni (239-266) : Rotazione di un nodo.

tree_print (188) : Si occupa di stampare l'albero. 
Fondamentalmente ogni livello viene diviso in n sezioni pari a 2 elevato all'altezza dell'albero.
Questo sistema cerca di vididere ogni riga di stampa in 2^n posizioni in cui verranno
inseriti i valori per ottenere un albero simmetrico.

La funzione "print_line" (102) si occupa di stampare i valori di ogni riga, è possibile
cambiare i colori di stampa modificando le printf in riga : 117,125,155,157,164 e 166.

Il parametro da modificare è, all'interno della stringa "\033[1;30m%s%d\033[0m", la sottostringa "1;30".

Ad inizio file tmp.h sono presenti dei valori da sostiuire per cambiare il colore della stampa.
Ad esempio per stampare una stringa rossa è sufficiente sostituire "1;30" con "1;31".

Es : printf("\033[1;31m %d \033[0m", val); Stampa valore rosso.
     printf("\033[1;30m %d \033[0m", val); Stampa valore nero.

Credo di aver detto tutto, per qualsiasi cosa mi faccia sapere!